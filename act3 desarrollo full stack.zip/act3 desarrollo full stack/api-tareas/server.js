const express = require('express');
const fs = require('fs').promises;
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;

// ================= MIDDLEWARE =================
app.use(express.json());

// ================= FUNCIONES =================
async function leerTareas() {
  const data = await fs.readFile('tareas.json', 'utf8');
  return JSON.parse(data);
}

async function guardarTareas(tareas) {
  await fs.writeFile('tareas.json', JSON.stringify(tareas, null, 2));
}

// ================= AUTENTICACIÓN =================
const usuarios = [];

// Registro
app.post('/register', async (req, res, next) => {
  try {
    const hash = await bcrypt.hash(req.body.password, 10);

    usuarios.push({
      username: req.body.username,
      password: hash
    });

    res.status(201).json({ mensaje: 'Usuario registrado' });
  } catch (error) {
    next(error);
  }
});

// Login
app.post('/login', async (req, res, next) => {
  try {
    const usuario = usuarios.find(u => u.username === req.body.username);
    if (!usuario) {
      return res.status(401).json({ mensaje: 'Usuario no válido' });
    }

    const valido = await bcrypt.compare(req.body.password, usuario.password);
    if (!valido) {
      return res.status(401).json({ mensaje: 'Contraseña incorrecta' });
    }

    const token = jwt.sign({ username: usuario.username }, 'clave_secreta');
    res.json({ token });
  } catch (error) {
    next(error);
  }
});

// Middleware de autenticación
function autenticarToken(req, res, next) {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ mensaje: 'Acceso denegado' });
  }

  jwt.verify(token, 'clave_secreta', (err, user) => {
    if (err) {
      return res.status(403).json({ mensaje: 'Token inválido' });
    }
    req.user = user;
    next();
  });
}

// ================= RUTAS DE TAREAS (PROTEGIDAS) =================

// GET
app.get('/tareas', autenticarToken, async (req, res, next) => {
  try {
    const tareas = await leerTareas();
    res.json(tareas);
  } catch (error) {
    next(error);
  }
});

// POST
app.post('/tareas', autenticarToken, async (req, res, next) => {
  try {
    const tareas = await leerTareas();

    const nuevaTarea = {
      id: Date.now(),
      titulo: req.body.titulo,
      descripcion: req.body.descripcion
    };

    tareas.push(nuevaTarea);
    await guardarTareas(tareas);

    res.status(201).json(nuevaTarea);
  } catch (error) {
    next(error);
  }
});

// PUT
app.put('/tareas/:id', autenticarToken, async (req, res, next) => {
  try {
    const tareas = await leerTareas();
    const id = parseInt(req.params.id);

    const tarea = tareas.find(t => t.id === id);
    if (!tarea) {
      return res.status(404).json({ mensaje: 'Tarea no encontrada' });
    }

    tarea.titulo = req.body.titulo;
    tarea.descripcion = req.body.descripcion;

    await guardarTareas(tareas);
    res.json(tarea);
  } catch (error) {
    next(error);
  }
});

// DELETE
app.delete('/tareas/:id', autenticarToken, async (req, res, next) => {
  try {
    const tareas = await leerTareas();
    const id = parseInt(req.params.id);

    const nuevasTareas = tareas.filter(t => t.id !== id);
    await guardarTareas(nuevasTareas);

    res.json({ mensaje: 'Tarea eliminada' });
  } catch (error) {
    next(error);
  }
});

// ================= MANEJO DE ERRORES =================
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Error en el servidor' });
});

// ================= SERVIDOR =================
app.listen(port, () => {
  console.log(`Servidor funcionando en http://localhost:${port}`);
});
